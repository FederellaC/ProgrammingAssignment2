Functions that optimize the time spent to calculate the inverse of a matrix.

Object that caches the inverse of a matrix

makeCacheMatrix <- function (x = matrix()) {
  inv <- NULL
  set <- function(y){
    x <<- y
    inv <<- NULL
  }
  get <- function() {x}
  setInverse <- function(inverse) {inv <<- inverse}
  getInverse <- function () {inv}
  list(set = set, get = get, setInverse = setInverse, getInverse = getInverse)
}



The following object computes the inverse of the special matrix returned by the object above. If the inverse was calculated by makeCacheMatrix, this object should get the inverse from the Cache.

cacheSolve <- function(x, ...) {
  inv <- x$getInverse()
  if(!is.null(inv)) {
    message("getting cached data")
    return(inv)
  }
  mat <- x$get()
  inv <- solve(mat, ...)
  x$setInverse(inv)
  inv
}
